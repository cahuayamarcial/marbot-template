"use strict"

let items = 
[
    //Heads
    [
        { name: 'Good', item1: 21, item2: 0, item3: 19, item4: 0, item5: 0, item6: 21, item7: 0, item8: 21 },
        { name: 'Demon', item1: 11, item2: 18, item3: 20, item4: 6, item5: 1, item6: 11, item7: 2, item8: 0 },
        { name: 'Hash', item1: 10, item2: 22, item3: 3, item4: 20, item5: 10, item6: 9, item7: 20, item8: 0 },
        { name: 'Doeh', item1: 4, item2: 0, item3: 0, item4: 10, item5: 0, item6: 0, item7: 0, item8: 0 },
    ],
  
    //Bodies
    [
        { name: 'Good', item1: 12, item2: 0, item3: 0, item4: 18, item5: 25, item6: 0, item7: 0, item8: 21 },
        { name: 'Maxi', item1: 11, item2: 8, item3: 0, item4: 6, item5: 1, item6: 11, item7: 2, item8: 0 },
        { name: 'Death', item1: 10, item2: 2, item3: 13, item4: 20, item5: 10, item6: 9, item7: 10, item8: 17 },
        { name: 'Motal', item1: 4, item2: 0, item3: 0, item4: 10, item5: 0, item6: 0, item7: 0, item8: 0 },
        { name: 'Doeh', item1: 0, item2: 20, item3: 0, item4: 7, item5: 0, item6: 17, item7: 0, item8: 20 },
    ],
  
    //Glasses
    [
        { name: 'Glass', item1: 0, item2: 0, item3: 21, item4: 22, item5: 24, item6: 0, item7: 0, item8: 0, },
        { name: 'Doeh', item1: 0, item2: 20, item3: 0, item4: 7, item5: 0, item6: 17, item7: 0, item8: 5 },
    ],
  
    //Flags
    [
        { name: 'Motal', item1: 0, item2: 0, item3: 5, item4: 12, item5: 4, item6: 0, item7: 0, item8: 0 },
        { name: 'Maxi', item1: 15, item2: 15, item3: 5, item4: 10, item5: 0, item6: 0, item7: 0, item8: 0 },
        { name: 'khon', item1: 4, item2: 0, item3: 0, item4: 10, item5: 0, item6: 0, item7: 0, item8: 0 },
    ]
]

//Número total de combinaciones
//https://appdividend.com/2018/12/18/javascript-array-reduce-example-array-prototype-reduce-tutorial/
let t = items.reduce(function (t, c) {  return t * c.length }, 1)

//Se realizan todas las combinaciones
let c = cartesian(items[0], items[1], items[2], items[3])

//Declara array final
let f = []

//Concatena la suma de combinaciones
for(let i = 0; i < t; i++){
    f.push(union(c.next().value))
}

//https://gist.github.com/pste/8915a860e3aaf33e3fba1ab93f5de962

//Se declara la secuencia del ordenamiento según los items (Orden items: 2, 1, 6, 3, 4, 5, 6, 7, 8)
let atrib = { 
    //Orden relevante
    item2: true, 
    item1: true, 
    item6: true,
    //Orden no relevante
    item3: true, 
    item4: true, 
    item5: true, 
    item6: true,
    item7: true,
    item8: true 
} 

// Se ordena los items
f.sort((a,b) => {
  for (let col in atrib) { // Posicion
    if (a[col] != b[col]) { // Comparación
      if (atrib[col] === true) return a[col] < b[col] // Si *DESC(<) / ASC(>) === true
      else return a[col] > b[col] // *DESC(>) / ASC(<)
    }
  }
})

console.log(f)

f.forEach(e => {
    let p = ''
    for(let i = 1; i <= 8; i++){
        p += '<td>'+e[`item${i}`]+'</td>'
    }
    $('#myTable').find('tbody').append(`<tr><td>${e.name}</td>${p}</tr>`)
})


//FUNCIONES

//https://stackoverflow.com/questions/4331092/finding-all-combinations-cartesian-product-of-javascript-array-values
function* cartesian(head, ...tail) {
    let remainder = tail.length ? cartesian(...tail) : [[]]
    for (let r of remainder) for (let h of head) yield [h, ...r]
}

function union(r){
    let a = {
        name: "",
        item1: 0,
        item2: 0,
        item3: 0,
        item4: 0,
        item5: 0,
        item6: 0,
        item7: 0,
        item8: 0
    }

    for(let i = 0; i < r.length; i++){
        a.name += r[i].name + ' '
        for(let j = 1; j <= 8; j++){
            a[`item${ j }`] += r[i][`item${ j }`]
        }
    }
    return a
}

  